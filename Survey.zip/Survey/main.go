package main

import (
	"Survey/config"
	"Survey/controller"

	"github.com/gin-gonic/gin"
)

func main() {
	config.ConnectionDatabase()
	r := gin.Default()
	survey := r.Group("/survey")
	{
		survey.POST("/", controller.CreateSurvey)
		survey.GET("/:id", controller.GetServey)
		survey.GET("/", controller.GetAllsurvey)
	}
	r.Run(":8080")
}
