package controller

import (
	"Survey/config"
	"Survey/model"
	"net/http"

	"github.com/gin-gonic/gin"
)

func CreateSurvey(c *gin.Context) {
	var survey model.Survey
	if err := c.ShouldBindJSON(&survey); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "error"})
	}
	config.DB.Create(&survey)
	c.JSON(http.StatusOK, survey)

}

func GetServey(c *gin.Context) {
	var survey model.Survey
	id := c.Param("id")

	if survey.ID == 0 {
		c.JSON(http.StatusNotFound, gin.H{"message": "survery not found"})

	}
	config.DB.Preload("Questions").First(&survey, id)

	c.JSON(http.StatusOK, survey)
}

func GetAllsurvey(c *gin.Context) {
	var surveys []model.Survey
	config.DB.Preload("Question").Find(&surveys)
	c.JSON(http.StatusOK, surveys)
}
