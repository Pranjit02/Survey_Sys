package model

import "gorm.io/gorm"

type Survey struct {
	gorm.Model
	Title       string
	Description string
	Questions   []Questions
	//`gorm:"foreignkey:SurveyID"`

}

type Choice struct {
	gorm.Model

	QuestionId int
	Text       string
}

type Questions struct {
	gorm.Model
	SurveyID string
	Text     string
	Type     string
	Choice   []Choice
}

type UserTable struct {
	gorm.Model
	Name     string
	Email    string
	Password string
	Role     string
	//`gorm:"foreignkey:SurveyID"`

}

type Reponse struct {
	gorm.Model
	UserID     int
	SurveyID   int
	QuestionId int
	Answer     string
	//`gorm:"foreignkey:SurveyID"`

}
