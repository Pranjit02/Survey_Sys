package main

import "testing"

// req, _ := http.NewRequest(http.MethodPost, "/signup", strings.NewReader(string(jsonStr)))
// req.Header.Set("Content-Type", "application/json")

// // Setting and recording the response
// res := httptest.NewRecorder()
// handler := http.HandlerFunc(SignUp)

// handler.ServeHTTP(res, req)

// if res.Code != e.expectedStatusCode {
// 	t.Errorf("%s: returned wrong status code; expected %d but got %d", e.name, e.expectedStatusCode, res.Code)
// }

func Test_main(t *testing.T) {
	tests := []struct {
		Name     string
		Email    string
		Password string
		Role     string
	}{
		Name:     "pranjit",
		Email:    "pranjit@gmail.com",
		Password: "pranjit123", //MD5
		Role:     "user",
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			main()
		})
	}
}
